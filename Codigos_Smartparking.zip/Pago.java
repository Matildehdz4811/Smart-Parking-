import java.util.Date;
public class Pago {
    private int idPago;
    private String metodo;
    private String monto;
    private Date fechaPago;
    public Pago(int idPago, String metodo, String monto, Date fechaPago) {
        this.idPago = idPago;
        this.metodo = metodo;
        this.monto = monto;
        this.fechaPago = fechaPago;
    }
}
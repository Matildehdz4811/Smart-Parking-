public class Vehiculo {
    private int idVehiculo;
    private String placa;
    private String modelo;
    public Vehiculo(int idVehiculo, String placa, String modelo) {
        this.idVehiculo = idVehiculo;
        this.placa = placa;
        this.modelo = modelo;
    }
}
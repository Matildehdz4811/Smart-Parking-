import java.util.Date;
public class Reserva {
    private Date idReserva;
    private double monto;
    private String metodo;
    private String disponibilidad;
    public Reserva(Date idReserva, double monto, String metodo, String disponibilidad) {
        this.idReserva = idReserva;
        this.monto = monto;
        this.metodo = metodo;
        this.disponibilidad = disponibilidad;
    }
}